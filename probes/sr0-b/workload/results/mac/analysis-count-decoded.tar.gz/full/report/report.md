# SR0 workload report (macos): FAIL

| id | run | status | check | value | limit |
|---|---|---|---|---|---|
| P | r1 | PASS | window size pinned (960x640 pt) | True | bool True |
| P | r1 | PASS | release build | True | bool True |
| P | r1 | PASS | full instrumentation level | True | bool True |
| W1 | r1 | PASS | wrong-node edits | 0 | == 0 |
| W1 | r1 | PASS | stale-owner result commits | 0 | == 0 |
| W1 | r1 | PASS | commits after window close | 0 | == 0 |
| W1 | r1 | PASS | row count constant (min=max=200) | True | bool True |
| W1 | r1 | PASS | unique stable row ids | True | bool True |
| W1 | r1 | PASS | run completed (app_exit complete, window closed) | True | bool True |
| W1 | r1 | PASS | cancellation exercised (stale results rejected > 0) | True | bool True |
| W1 | r1 | PASS | interrupted animation exercised | True | bool True |
| W0 | r1 | PASS | async ops delivered (>= 95% of 20/s) | True | bool True |
| W0 | r1 | PASS | reorders delivered (>= 1/s) | True | bool True |
| W1 | r1 | PASS | lost valid edits (keys posted - applied) | 0 | == 0 |
| W1 | r1 | PASS | active text equals posted sequence | True | bool True |
| CAL | r1 | PASS | recorder calibration present and valid | True | bool True |
| CAL | r1 | PASS | recorder latency floor p95 (ms) | 23.2945 | <= 34.0 |
| CAL | r1 | PASS | response-region self-check (>= 90% of keys resolved) | True | bool True |
| CAL | r1 | PASS | captured frame size equals window pixel size (+-2 px) | True | bool True |
| P | r1 | PASS | recorder permissions | True | bool True |
| W4 | r1 | PASS | every key in the window has a visible response | 0 | == 0 |
| W4 | r1 | FAIL | input->visible p95 (ms) | 75.9400 | <= 50.0 |
| W4 | r1 | FAIL | input->visible p99 (ms) | 107.9449 | <= 100.0 |
| CAL | r1 | PASS | keys in window (script delivered 10/s) | True | bool True |
| W5 | r1 | PASS | display refresh 60 Hz (CGDisplayMode) | True | bool True |
| W5 | r1 | PASS | missed vblanks (SCK display-time interval > 1.5 x refresh) | 0 | == 0 |
| W5 | r1 | FAIL | presented interval p95 (ms) <= refresh + 0.1 | 17.9441 | <= 16.76666666666667 |
| W6 | r1 | INFO | main-actor enqueue->exec p99 (ms) (Windows-only threshold; reported) | 68.2067 | info 16.7 |
| P | r2 | PASS | window size pinned (960x640 pt) | True | bool True |
| P | r2 | PASS | release build | True | bool True |
| P | r2 | PASS | full instrumentation level | True | bool True |
| W1 | r2 | PASS | wrong-node edits | 0 | == 0 |
| W1 | r2 | PASS | stale-owner result commits | 0 | == 0 |
| W1 | r2 | PASS | commits after window close | 0 | == 0 |
| W1 | r2 | PASS | row count constant (min=max=200) | True | bool True |
| W1 | r2 | PASS | unique stable row ids | True | bool True |
| W1 | r2 | PASS | run completed (app_exit complete, window closed) | True | bool True |
| W1 | r2 | PASS | cancellation exercised (stale results rejected > 0) | True | bool True |
| W1 | r2 | PASS | interrupted animation exercised | True | bool True |
| W0 | r2 | PASS | async ops delivered (>= 95% of 20/s) | True | bool True |
| W0 | r2 | PASS | reorders delivered (>= 1/s) | True | bool True |
| W1 | r2 | PASS | lost valid edits (keys posted - applied) | 0 | == 0 |
| W1 | r2 | PASS | active text equals posted sequence | True | bool True |
| CAL | r2 | PASS | recorder calibration present and valid | True | bool True |
| CAL | r2 | PASS | recorder latency floor p95 (ms) | 23.7569 | <= 34.0 |
| CAL | r2 | PASS | response-region self-check (>= 90% of keys resolved) | True | bool True |
| CAL | r2 | PASS | captured frame size equals window pixel size (+-2 px) | True | bool True |
| P | r2 | PASS | recorder permissions | True | bool True |
| W4 | r2 | PASS | every key in the window has a visible response | 0 | == 0 |
| W4 | r2 | FAIL | input->visible p95 (ms) | 71.6462 | <= 50.0 |
| W4 | r2 | PASS | input->visible p99 (ms) | 88.2370 | <= 100.0 |
| CAL | r2 | PASS | keys in window (script delivered 10/s) | True | bool True |
| W5 | r2 | PASS | display refresh 60 Hz (CGDisplayMode) | True | bool True |
| W5 | r2 | PASS | missed vblanks (SCK display-time interval > 1.5 x refresh) | 0 | == 0 |
| W5 | r2 | FAIL | presented interval p95 (ms) <= refresh + 0.1 | 17.8242 | <= 16.76666666666667 |
| W6 | r2 | INFO | main-actor enqueue->exec p99 (ms) (Windows-only threshold; reported) | 65.9581 | info 16.7 |
| P | r3 | PASS | window size pinned (960x640 pt) | True | bool True |
| P | r3 | PASS | release build | True | bool True |
| P | r3 | PASS | full instrumentation level | True | bool True |
| W1 | r3 | PASS | wrong-node edits | 0 | == 0 |
| W1 | r3 | PASS | stale-owner result commits | 0 | == 0 |
| W1 | r3 | PASS | commits after window close | 0 | == 0 |
| W1 | r3 | PASS | row count constant (min=max=200) | True | bool True |
| W1 | r3 | PASS | unique stable row ids | True | bool True |
| W1 | r3 | PASS | run completed (app_exit complete, window closed) | True | bool True |
| W1 | r3 | PASS | cancellation exercised (stale results rejected > 0) | True | bool True |
| W1 | r3 | PASS | interrupted animation exercised | True | bool True |
| W0 | r3 | PASS | async ops delivered (>= 95% of 20/s) | True | bool True |
| W0 | r3 | PASS | reorders delivered (>= 1/s) | True | bool True |
| W1 | r3 | PASS | lost valid edits (keys posted - applied) | 0 | == 0 |
| W1 | r3 | PASS | active text equals posted sequence | True | bool True |
| CAL | r3 | PASS | recorder calibration present and valid | True | bool True |
| CAL | r3 | PASS | recorder latency floor p95 (ms) | 23.2168 | <= 34.0 |
| CAL | r3 | PASS | response-region self-check (>= 90% of keys resolved) | True | bool True |
| CAL | r3 | PASS | captured frame size equals window pixel size (+-2 px) | True | bool True |
| P | r3 | PASS | recorder permissions | True | bool True |
| W4 | r3 | PASS | every key in the window has a visible response | 0 | == 0 |
| W4 | r3 | FAIL | input->visible p95 (ms) | 78.9379 | <= 50.0 |
| W4 | r3 | PASS | input->visible p99 (ms) | 95.6121 | <= 100.0 |
| CAL | r3 | PASS | keys in window (script delivered 10/s) | True | bool True |
| W5 | r3 | PASS | display refresh 60 Hz (CGDisplayMode) | True | bool True |
| W5 | r3 | PASS | missed vblanks (SCK display-time interval > 1.5 x refresh) | 0 | == 0 |
| W5 | r3 | FAIL | presented interval p95 (ms) <= refresh + 0.1 | 17.9136 | <= 16.76666666666667 |
| W6 | r3 | INFO | main-actor enqueue->exec p99 (ms) (Windows-only threshold; reported) | 59.2097 | info 16.7 |
| W7 | set | PASS | Rust compiler invocations during UI-only incremental builds | 0 | == 0 |
| W7 | set | PASS | renderer / engine artifact hashes identical | True | bool True |
| W7 | set | PASS | incremental builds succeeded | True | bool True |
