#!/bin/sh
D=/Volumes/D/claude/swiftright/probes/sr0-s/fresh-on-bridge/out/tuple12-cross20-sbx1
S=$HOME/sr0-scratch/sr-refs-host
X=/Volumes/D/claude/swiftright/probes/sr0-o/f1-cross/cross
mkdir -p $S/xcmp-sbx; p=0; f=0
while read c i; do
  t=s12$i; o=$S/xcmp-sbx/$c-$t
  $S/bin/F1Assemble win --rec $D/out/winrec-$c-$t.json --side $D/out/winside-$c-$t.json --events $D/out/events-$c-$t.txt --stimulus $X/$c/stimulus.json --out $o-trace.json --keep-lists >$o-asm.log 2>&1 || { echo "$c $t ASMFAIL"; continue; }
  if $S/cmp-src/.build/release/sr0o-trace compare $S/mac20/$c/mac-trace-n$i.json $o-trace.json --adapt $X/$c/adapt-v0.json > $o-cmp.json 2>&1; then p=$((p+1)); else f=$((f+1)); echo "$c $t FAIL"; fi
done < $D/ctl/list.txt
echo "pass=$p fail=$f"
