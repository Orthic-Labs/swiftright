#!/bin/sh
# Tuple 13 x20 cross-compare: Mac run n<i> (host Mac refs, 18 Oct) vs Windows Sandbox run s13<i> (renderer 1aa8ad22), per config, adapt-v0.
set -u
R=/Volumes/D/claude/swiftright
X=$R/probes/sr0-o/f1-cross/cross
W=$R/probes/sr0-s/fresh-on-bridge/out/tuple13-cross20-sbx1/out
S=$HOME/sr0-scratch/sr-refs-host
OUT=$S/xcmp13
mkdir -p "$OUT"
for c in F1 F2 F3 F3-list-1s F3-list-3s F3-vstack-1s F3-vstack-3s F3-lazy-1s F3-lazy-3s F4 F5 F6 F6-reduced F7 F8 F9; do
  o=$OUT/$c; mkdir -p "$o"; pass=0; fail=0; asmfail=0; fails=""
  for i in $(seq 1 20); do
    t=s13$i
    if ! $S/bin/F1Assemble win --rec "$W/winrec-$c-$t.json" --side "$W/winside-$c-$t.json" --events "$W/events-$c-$t.txt" \
         --stimulus "$X/$c/stimulus.json" --out "$o/win-trace-$t.json" --keep-lists >"$o/win-asm-$t.log" 2>&1; then
      asmfail=$((asmfail+1)); fails="$fails asm:$i"; continue
    fi
    if $S/cmp-src/.build/release/sr0o-trace compare "$S/mac20/$c/mac-trace-n$i.json" "$o/win-trace-$t.json" --adapt "$X/$c/adapt-v0.json" >"$o/cmp-n$i-$t.json" 2>"$o/cmp-n$i-$t.err"; then
      pass=$((pass+1)); else fail=$((fail+1)); fails="$fails $i"; fi
  done
  echo "$c pass=$pass fail=$fail asmfail=$asmfail${fails:+ failing:$fails}"
done
