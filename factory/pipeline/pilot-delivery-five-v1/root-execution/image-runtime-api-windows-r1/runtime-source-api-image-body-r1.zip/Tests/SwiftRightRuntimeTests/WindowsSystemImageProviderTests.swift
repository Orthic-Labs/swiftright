#if os(Windows)
import XCTest
@testable import SwiftRightRuntime

final class WindowsSystemImageProviderTests: XCTestCase {
    func testDeclaredSegoeGlyphReturnsExactFaceAndCoverage() throws {
        let coverage = try WindowsSystemImageProvider.rasterize(
            WindowsSystemImageGlyphRequest(providerFamily: "Segoe Fluent Icons",
                                            glyph: 0xE735,
                                            targetWidth: 80,
                                            targetHeight: 80))
        XCTAssertEqual(coverage.selectedFace, "Segoe Fluent Icons")
        XCTAssertEqual(coverage.rowOrder, .topDown)
        XCTAssertGreaterThan(coverage.sourceWidth, 0)
        XCTAssertGreaterThan(coverage.sourceHeight, 0)
        XCTAssertGreaterThan(coverage.averageCharWidth, 0)
        XCTAssertGreaterThan(coverage.cellIncrementX, 0)
        XCTAssertTrue(coverage.coverage.contains { $0 > 0 })
    }

    func testInvalidTargetFailsBeforeNativeAllocation() {
        XCTAssertThrowsError(try WindowsSystemImageProvider.rasterize(
            WindowsSystemImageGlyphRequest(providerFamily: "Segoe Fluent Icons",
                                            glyph: 0xE735,
                                            targetWidth: 0,
                                            targetHeight: 80))) { error in
            XCTAssertEqual(error as? WindowsSystemImageProviderError, .invalidRequest)
        }
    }
}
#endif
