import SwiftRightRuntime
import XCTest

final class NativeWindowsBodyFontTests: XCTestCase {
    func testRejectsOutOfRangeDPIBeforePlatformResolution() {
        XCTAssertThrowsError(try NativeWindowsBodyFontResolver.resolve(dpi: 0, emitLog: false)) { error in
            XCTAssertEqual(error as? NativeWindowsBodyFontError, .invalidDPI)
        }
    }

    func testPublicPolicyValuePreservesMeasuredUnitsAndIdentity() {
        let policy = NativeWindowsBodyFont(
            family: "profile-family", fontSizeDIP: 16, lineHeightDIP: 24,
            weight: 400, logFontHeight: -16, textMetricHeight: 24,
            textMetricAscent: 18, textMetricDescent: 5,
            textMetricExternalLeading: 1, dpi: 96,
            sourceAPI: "test-profile")
        XCTAssertEqual(policy.family, "profile-family")
        XCTAssertEqual(policy.fontSizeDIP, 16)
        XCTAssertEqual(policy.lineHeightDIP, 24)
        XCTAssertEqual(policy.dpi, 96)
        XCTAssertEqual(policy.sourceAPI, "test-profile")
    }
}
