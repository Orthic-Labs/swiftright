import Foundation

/// Small dependency-free SHA-256 used on Windows where CryptoKit is unavailable.
/// Callers may feed chunks incrementally; digest is finalized only after all bytes arrive.
struct FactorySHA256 {
    private static let initial: [UInt32] = [
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
        0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    ]
    private static let round: [UInt32] = [
        0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
    ]
    private var state = initial
    private var pending: [UInt8] = []
    private var byteCount: UInt64 = 0

    private static func rotateRight(_ value: UInt32, _ amount: UInt32) -> UInt32 {
        (value >> amount) | (value << (32 - amount))
    }

    private mutating func process(_ block: ArraySlice<UInt8>) {
        var words = Array(repeating: UInt32(0), count: 64)
        for index in 0..<16 {
            let offset = block.startIndex + index * 4
            words[index] = (UInt32(block[offset]) << 24) | (UInt32(block[offset + 1]) << 16) |
                (UInt32(block[offset + 2]) << 8) | UInt32(block[offset + 3])
        }
        for index in 16..<64 {
            let x = words[index - 15]
            let y = words[index - 2]
            let s0 = Self.rotateRight(x, 7) ^ Self.rotateRight(x, 18) ^ (x >> 3)
            let s1 = Self.rotateRight(y, 17) ^ Self.rotateRight(y, 19) ^ (y >> 10)
            words[index] = words[index - 16] &+ s0 &+ words[index - 7] &+ s1
        }
        var a = state[0], b = state[1], c = state[2], d = state[3]
        var e = state[4], f = state[5], g = state[6], h = state[7]
        for index in 0..<64 {
            let s1 = Self.rotateRight(e, 6) ^ Self.rotateRight(e, 11) ^ Self.rotateRight(e, 25)
            let choose = (e & f) ^ ((~e) & g)
            let temp1 = h &+ s1 &+ choose &+ Self.round[index] &+ words[index]
            let s0 = Self.rotateRight(a, 2) ^ Self.rotateRight(a, 13) ^ Self.rotateRight(a, 22)
            let majority = (a & b) ^ (a & c) ^ (b & c)
            let temp2 = s0 &+ majority
            h = g; g = f; f = e; e = d &+ temp1
            d = c; c = b; b = a; a = temp1 &+ temp2
        }
        state[0] &+= a; state[1] &+= b; state[2] &+= c; state[3] &+= d
        state[4] &+= e; state[5] &+= f; state[6] &+= g; state[7] &+= h
    }

    mutating func update(data: Data) {
        byteCount &+= UInt64(data.count)
        pending.append(contentsOf: data)
        while pending.count >= 64 {
            process(pending[0..<64])
            pending.removeFirst(64)
        }
    }

    mutating func finalizeHex() -> String {
        var tail = pending
        tail.append(0x80)
        while tail.count % 64 != 56 { tail.append(0) }
        let bitCount = byteCount &* 8
        for shift in stride(from: 56, through: 0, by: -8) {
            tail.append(UInt8((bitCount >> UInt64(shift)) & 0xff))
        }
        var index = 0
        while index < tail.count {
            process(tail[index..<(index + 64)])
            index += 64
        }
        return state.map { String(format: "%08x", $0) }.joined()
    }

    static func hash(data: Data) -> String {
        var hasher = Self(); hasher.update(data: data)
        return "sha256:" + hasher.finalizeHex()
    }

    static func hash(fileAt url: URL) throws -> String {
        let handle = try FileHandle(forReadingFrom: url)
        var hasher = Self()
        while let chunk = try handle.read(upToCount: 1 << 20), !chunk.isEmpty { hasher.update(data: chunk) }
        return "sha256:" + hasher.finalizeHex()
    }
}
